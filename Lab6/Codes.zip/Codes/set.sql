select id from student101
union
select id from student_result101;