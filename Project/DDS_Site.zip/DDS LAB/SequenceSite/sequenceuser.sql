Create Sequence site_sequence_user
Start with 1
MAXVALUE 9999
MINVALUE 1
NOCYCLE
CACHE 20
NOORDER;