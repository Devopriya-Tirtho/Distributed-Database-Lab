set serveroutput on;

declare


begin

	procMaxMinSalary;


end;
/